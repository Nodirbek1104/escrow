import { CompleteRegisterDto } from './create-user.dto';
import { UserRole } from '../entities/user.entity';
export declare class AdminCreateDto extends CompleteRegisterDto {
    role?: UserRole;
}
