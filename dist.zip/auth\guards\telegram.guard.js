"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var TelegramGuard_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TelegramGuard = void 0;
const common_1 = require("@nestjs/common");
const crypto = __importStar(require("crypto"));
let TelegramGuard = TelegramGuard_1 = class TelegramGuard {
    logger = new common_1.Logger(TelegramGuard_1.name);
    canActivate(context) {
        const request = context.switchToHttp().getRequest();
        const tgData = request.headers['x-tg-data'];
        if (process.env.NODE_ENV === 'development' && !tgData) {
            return true;
        }
        if (!tgData) {
            throw new common_1.UnauthorizedException('Telegram maʼlumotlari topilmadi (Missing x-tg-data)');
        }
        if (!this.validate(tgData)) {
            throw new common_1.UnauthorizedException('Telegram maʼlumotlari haqiqiy emas (Invalid Telegram Hash)');
        }
        return true;
    }
    validate(data) {
        const botToken = process.env.TG_BOT_TOKEN;
        if (!botToken) {
            this.logger.error('TG_BOT_TOKEN topilmadi! .env faylini tekshiring.');
            return false;
        }
        try {
            const urlParams = new URLSearchParams(data);
            const hash = urlParams.get('hash');
            urlParams.delete('hash');
            const dataCheckString = Array.from(urlParams.entries())
                .sort(([a], [b]) => a.localeCompare(b))
                .map(([key, value]) => `${key}=${value}`)
                .join('\n');
            const secretKey = crypto
                .createHmac('sha256', 'WebAppData')
                .update(botToken)
                .digest();
            const calculatedHash = crypto
                .createHmac('sha256', secretKey)
                .update(dataCheckString)
                .digest('hex');
            return calculatedHash === hash;
        }
        catch (e) {
            this.logger.error(`Validation error: ${e.message}`);
            return false;
        }
    }
};
exports.TelegramGuard = TelegramGuard;
exports.TelegramGuard = TelegramGuard = TelegramGuard_1 = __decorate([
    (0, common_1.Injectable)()
], TelegramGuard);
//# sourceMappingURL=telegram.guard.js.map