"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var PaymentService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const axios_1 = __importDefault(require("axios"));
const payment_entity_1 = require("./entities/payment.entity");
const payment_error_handler_1 = require("./utils/payment-error.handler");
const config_1 = require("@nestjs/config");
let PaymentService = PaymentService_1 = class PaymentService {
    cardRepository;
    configService;
    client;
    logger = new common_1.Logger(PaymentService_1.name);
    constructor(cardRepository, configService) {
        this.cardRepository = cardRepository;
        this.configService = configService;
        const baseUrl = this.configService.get('PAYLOV_BASE_URL');
        const token = this.configService.get('PAYLOV_TOKEN');
        const merchantId = this.configService.get('PAYLOV_MERCHANT_ID');
        if (!baseUrl) {
            console.error('DIQQAT: PAYLOV_BASE_URL topilmadi!');
        }
        this.client = axios_1.default.create({
            baseURL: baseUrl,
            headers: {
                'Authorization': `Bearer ${token}`,
                'Merchant-Id': merchantId,
                'Content-Type': 'application/json',
            },
        });
    }
    async createCard(userId, cardNumber, expireDate, phoneNumber) {
        try {
            if (!userId) {
                throw new common_1.BadRequestException('Foydalanuvchi ID-si (userId) taqdim etilmadi');
            }
            const { data } = await this.client.post('/cards/create', {
                userId: String(userId),
                cardNumber: cardNumber.replace(/\s+/g, ''),
                expireDate: expireDate.replace(/\//g, ''),
                phoneNumber: phoneNumber.replace(/\+/g, ''),
            });
            return data;
        }
        catch (error) {
            this.logger.error(`Paylov API Error: ${error}`);
            if (error instanceof TypeError && error.message.includes('Invalid URL')) {
                return {
                    status: 'error',
                    message: ".env faylida PAYLOV_BASE_URL noto'g'ri ko'rsatilgan",
                };
            }
            return (0, payment_error_handler_1.handlePaymentError)(error);
        }
    }
    async confirmCard(userId, cardId, otp, cardName, pinfl) {
        try {
            const { data } = await this.client.post('/cards/confirm', {
                cardId,
                otp,
                cardName,
                pinfl,
            });
            if (data.result && data.result.card) {
                const c = data.result.card;
                const existingCard = await this.cardRepository.findOne({ where: { cardId: c.cardId } });
                if (existingCard) {
                    await this.cardRepository.update({ cardId: c.cardId }, {
                        balance: c.balance,
                        isActive: c.status?.is_active ?? true,
                        statusMessage: c.status?.status_message
                    });
                }
                else {
                    const newCard = this.cardRepository.create({
                        cardId: c.cardId,
                        userId: userId,
                        owner: c.owner,
                        cardName: cardName || c.cardName,
                        number: c.number,
                        balance: c.balance,
                        expireDate: c.expireDate,
                        bankId: c.bankId,
                        vendor: c.vendor,
                        processing: c.processing,
                        isActive: c.status?.is_active ?? true,
                        statusMessage: c.status?.status_message,
                    });
                    await this.cardRepository.save(newCard);
                }
            }
            return data;
        }
        catch (error) {
            return (0, payment_error_handler_1.handlePaymentError)(error);
        }
    }
    async deleteCard(userId, cardId) {
        try {
            const card = await this.cardRepository.findOne({ where: { cardId, userId } });
            if (!card) {
                return { result: null, error: { code: 'card_not_found', message: 'Karta topilmadi' } };
            }
            const { data } = await this.client.post('/cards/delete', { cardId });
            if (data.result === true) {
                await this.cardRepository.remove(card);
            }
            return data;
        }
        catch (error) {
            return (0, payment_error_handler_1.handlePaymentError)(error);
        }
    }
    async getMyCards(userId) {
        try {
            const cards = await this.cardRepository.find({
                where: { userId },
                order: { createdAt: 'DESC' }
            });
            return { result: { cards }, error: null };
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : String(error);
            this.logger.error(`DB Get Cards Error: ${errorMessage}`);
            return {
                result: null,
                error: {
                    code: 'db_error',
                    message: errorMessage
                }
            };
        }
    }
    async getCardDetails(userId, cardId) {
        try {
            const cardExists = await this.cardRepository.findOne({ where: { cardId, userId } });
            if (!cardExists)
                throw new Error('Permission denied');
            const { data } = await this.client.get(`/cards/get/${cardId}`);
            return data;
        }
        catch (error) {
            return (0, payment_error_handler_1.handlePaymentError)(error);
        }
    }
    async checkCardData(cardId, type, value) {
        try {
            const endpoint = type === 'pinfl' ? '/cards/check-pnfl' : '/cards/check-phone-match';
            const payload = type === 'pinfl' ? { cardId, pinfl: value } : { cardId, phone: value };
            const { data } = await this.client.post(endpoint, payload);
            return data;
        }
        catch (error) {
            return (0, payment_error_handler_1.handlePaymentError)(error);
        }
    }
    async cancelTransaction(transactionId) {
        try {
            const { data } = await this.client.post('/transactions/cancel', { transactionId });
            return data;
        }
        catch (error) {
            return (0, payment_error_handler_1.handlePaymentError)(error);
        }
    }
    async holdFunds(userId, cardId, amount, contractId) {
        try {
            const card = await this.cardRepository.findOne({ where: { cardId, userId } });
            if (!card)
                throw new Error("Karta topilmadi yoki ruxsat yo'q");
            const { data } = await this.client.post('/transactions/create', {
                cardId,
                amount: amount * 100,
                description: `Escrow Contract #${contractId} uchun muzlatish`,
                extId: `contract_${contractId}_${Date.now()}`,
            });
            return data;
        }
        catch (error) {
            return (0, payment_error_handler_1.handlePaymentError)(error);
        }
    }
    async fulfillEscrow(transactionId, receiverCardId) {
        try {
            const { data } = await this.client.post('/transactions/confirm', {
                transactionId,
                receiverCardId,
            });
            return data;
        }
        catch (error) {
            return (0, payment_error_handler_1.handlePaymentError)(error);
        }
    }
};
exports.PaymentService = PaymentService;
exports.PaymentService = PaymentService = PaymentService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(payment_entity_1.Card)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        config_1.ConfigService])
], PaymentService);
//# sourceMappingURL=payment.service.js.map