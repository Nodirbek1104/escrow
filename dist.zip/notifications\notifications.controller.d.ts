import { NotificationsService } from './notifications.service';
export declare class NotificationsController {
    private readonly notificationsService;
    constructor(notificationsService: NotificationsService);
    findAll(req: any): Promise<import("./entities/notification.entity").Notification[]>;
    getUnreadCount(req: any): Promise<number>;
    markAsRead(id: number, req: any): Promise<import("typeorm").UpdateResult>;
    markAllAsRead(req: any): Promise<import("typeorm").UpdateResult>;
}
