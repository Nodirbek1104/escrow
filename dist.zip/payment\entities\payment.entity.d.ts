import { User } from '../../user/entities/user.entity';
export declare class Card {
    id: string;
    cardId: string;
    userId: number;
    user: User;
    owner: string;
    cardName: string;
    number: string;
    balance: number;
    expireDate: string;
    bankId: string;
    vendor: string;
    processing: string;
    isActive: boolean;
    statusMessage: string;
    createdAt: Date;
    updatedAt: Date;
}
