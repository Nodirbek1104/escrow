import { User } from '../../user/entities/user.entity';
export declare class AuditLog {
    id: number;
    userId: number | null;
    action: string;
    status: string;
    deviceId: number | null;
    ipAddress: string | null;
    headers: any;
    createdAt: Date;
    user: User | null;
}
