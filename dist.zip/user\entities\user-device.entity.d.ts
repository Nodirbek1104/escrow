import { User } from './user.entity';
export declare class UserDevice {
    id: number;
    userId: number;
    fingerprint: string;
    model: string;
    os: string;
    osVersion: string;
    appVersion: string;
    ipAddress: string;
    lastLogin: Date;
    user: User;
}
