import { UserService } from './user.service';
import { SendOtpDto, CompleteRegisterDto, LoginDto, VerifyOtpDto, ForgotPasswordDto, ResetPasswordDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
export declare class UserController {
    private readonly userService;
    constructor(userService: UserService);
    sendOtp(sendOtpDto: SendOtpDto): Promise<{
        message: string;
        hint: string;
    }>;
    verifyOtp(verifyOtpDto: VerifyOtpDto): Promise<{
        message: string;
    }>;
    register(completeDto: CompleteRegisterDto): Promise<{
        message: string;
    }>;
    login(loginDto: LoginDto): Promise<{
        access_token: string;
        user: {
            id: number;
            fullName: string;
            phoneNumber: string;
            role: import("./entities/user.entity").UserRole;
        };
    }>;
    getProfile(req: any): Promise<{
        id: number;
        phoneNumber: string;
        fullName: string;
        password: string;
        isVerified: boolean;
        role: import("./entities/user.entity").UserRole;
        otpCode?: string | null;
        otpExpires?: Date | null;
        createdContracts: import("../escrocontracts/entities/escrocontract.entity").EscrowContract[];
        cards: import("../payment/entities/payment.entity").Card[];
        createdAt: Date;
    }>;
    logout(req: any): Promise<{
        message: string;
    }>;
    updateProfile(req: any, dto: UpdateUserDto): Promise<import("./entities/user.entity").User>;
    forgotPassword(dto: ForgotPasswordDto): Promise<{
        message: string;
    }>;
    resetPassword(dto: ResetPasswordDto): Promise<{
        message: string;
    }>;
}
