"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaymentController = void 0;
const common_1 = require("@nestjs/common");
const payment_service_1 = require("./payment.service");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
let PaymentController = class PaymentController {
    paymentService;
    constructor(paymentService) {
        this.paymentService = paymentService;
    }
    async createCard(req, body) {
        const userId = req.user?.id || req.user?.userId;
        if (!userId) {
            throw new common_1.UnauthorizedException("Foydalanuvchi ma'lumotlari topilmadi. Tokenni tekshiring.");
        }
        return this.paymentService.createCard(userId, body.cardNumber, body.expireDate, body.phoneNumber);
    }
    async confirmCard(req, body) {
        return this.paymentService.confirmCard(req.user.id, body.cardId, body.otp, body.cardName, body.pinfl);
    }
    async deleteCard(req, cardId) {
        return this.paymentService.deleteCard(req.user.id, cardId);
    }
    async getMyCards(req) {
        return this.paymentService.getMyCards(req.user.id);
    }
    async getCardStatus(req, cardId) {
        return this.paymentService.getCardDetails(req.user.id, cardId);
    }
    async checkPinfl(body) {
        return this.paymentService.checkCardData(body.cardId, 'pinfl', body.pinfl);
    }
    async checkPhone(body) {
        return this.paymentService.checkCardData(body.cardId, 'phone', body.phone);
    }
    async cancelTransaction(transactionId) {
        return this.paymentService.cancelTransaction(transactionId);
    }
    async hold(req, body) {
        return this.paymentService.holdFunds(req.user.id, body.cardId, body.amount, body.contractId);
    }
    async fulfill(body) {
        return this.paymentService.fulfillEscrow(body.transactionId, body.receiverCardId);
    }
};
exports.PaymentController = PaymentController;
__decorate([
    (0, common_1.Post)('cards/create'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "createCard", null);
__decorate([
    (0, common_1.Post)('cards/confirm'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "confirmCard", null);
__decorate([
    (0, common_1.Delete)('cards/:cardId'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('cardId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "deleteCard", null);
__decorate([
    (0, common_1.Get)('cards/my'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "getMyCards", null);
__decorate([
    (0, common_1.Get)('cards/:cardId/status'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Param)('cardId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "getCardStatus", null);
__decorate([
    (0, common_1.Post)('cards/check-pnfl'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "checkPinfl", null);
__decorate([
    (0, common_1.Post)('cards/check-phone'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "checkPhone", null);
__decorate([
    (0, common_1.Post)('transactions/cancel'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    __param(0, (0, common_1.Body)('transactionId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "cancelTransaction", null);
__decorate([
    (0, common_1.Post)('escrow/hold'),
    __param(0, (0, common_1.Req)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "hold", null);
__decorate([
    (0, common_1.Post)('escrow/fulfill'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PaymentController.prototype, "fulfill", null);
exports.PaymentController = PaymentController = __decorate([
    (0, common_1.Controller)('payment'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [payment_service_1.PaymentService])
], PaymentController);
//# sourceMappingURL=payment.controller.js.map