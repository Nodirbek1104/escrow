import { MessagesService } from './messages.service';
export declare class MessagesController {
    private readonly messagesService;
    constructor(messagesService: MessagesService);
    getByContract(id: number): Promise<import("./entities/message.entity").Message[]>;
}
