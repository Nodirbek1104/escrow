import { Repository } from 'typeorm';
import { AuditLog } from './entities/audit-log.entity';
export declare class AuditLogService {
    private readonly auditLogRepo;
    constructor(auditLogRepo: Repository<AuditLog>);
    createLog(data: any): Promise<AuditLog | undefined>;
    findAll(): Promise<AuditLog[]>;
}
