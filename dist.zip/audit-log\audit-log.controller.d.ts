import { AuditLogService } from './audit-log.service';
export declare class AuditLogController {
    private readonly auditLogService;
    constructor(auditLogService: AuditLogService);
    findAll(): Promise<import("./entities/audit-log.entity").AuditLog[]>;
}
