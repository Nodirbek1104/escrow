import { Server, Socket } from 'socket.io';
import { MessagesService } from './messages.service';
import { JwtService } from '@nestjs/jwt';
export declare class MessagesGateway {
    private readonly messagesService;
    private readonly jwtService;
    server: Server;
    constructor(messagesService: MessagesService, jwtService: JwtService);
    handleConnection(client: Socket): Promise<void>;
    handleJoinContract(data: {
        contractId: number;
    }, client: Socket): {
        status: string;
        room: string;
    };
    handleMessage(data: {
        contractId: number;
        content: string;
        fileUrl?: string;
    }, client: Socket): Promise<import("./entities/message.entity").Message | undefined>;
}
