import { User } from '../../user/entities/user.entity';
import { EscrowContract } from '../../escrocontracts/entities/escrocontract.entity';
export declare class Message {
    id: number;
    content: string;
    fileUrl: string;
    contract: EscrowContract;
    contractId: number;
    sender: User;
    senderId: number;
    createdAt: Date;
}
