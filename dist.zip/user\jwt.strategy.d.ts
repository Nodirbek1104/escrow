import { Strategy, StrategyOptionsWithRequest } from 'passport-jwt';
import Redis from 'ioredis';
declare const JwtStrategy_base: new (...args: [opt: StrategyOptionsWithRequest] | [opt: import("passport-jwt").StrategyOptionsWithoutRequest]) => Strategy & {
    validate(...args: any[]): unknown;
};
export declare class JwtStrategy extends JwtStrategy_base {
    private readonly redis;
    constructor(redis: Redis);
    validate(req: any, payload: any): Promise<{
        userId: any;
        phone: any;
        role: any;
    } | null>;
}
export {};
