import { Repository } from 'typeorm';
import { Notification } from './entities/notification.entity';
export declare class NotificationsService {
    private readonly notificationRepo;
    constructor(notificationRepo: Repository<Notification>);
    create(userId: number, title: string, message: string, type?: string, relatedId?: string): Promise<Notification>;
    findAll(userId: number): Promise<Notification[]>;
    getUnreadCount(userId: number): Promise<number>;
    markAsRead(id: number, userId: number): Promise<import("typeorm").UpdateResult>;
    markAllAsRead(userId: number): Promise<import("typeorm").UpdateResult>;
}
