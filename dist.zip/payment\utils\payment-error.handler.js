"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handlePaymentError = handlePaymentError;
const common_1 = require("@nestjs/common");
const axios_1 = __importDefault(require("axios"));
const logger = new common_1.Logger('PaymentErrorHandler');
function handlePaymentError(error) {
    if (axios_1.default.isAxiosError(error)) {
        const axiosError = error;
        const errorData = axiosError.response?.data;
        logger.error(`Paylov API Error: ${JSON.stringify(errorData || axiosError.message)}`);
        if (errorData && errorData.error) {
            return {
                result: null,
                error: errorData.error,
            };
        }
        return {
            result: null,
            error: {
                code: 'service_unavailable',
                message: axiosError.message,
            },
        };
    }
    logger.error(`System Error: ${error}`);
    return {
        result: null,
        error: {
            code: 'internal_error',
            message: 'Something went wrong',
        },
    };
}
//# sourceMappingURL=payment-error.handler.js.map