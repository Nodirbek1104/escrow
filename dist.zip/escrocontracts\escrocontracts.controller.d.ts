import { EscrocontractsService } from './escrocontracts.service';
import { CreateEscrowContractDto } from './dto/create-escrocontract.dto';
import { EscrowStatus } from './entities/escrocontract.entity';
export declare class EscrocontractsController {
    private readonly escrowService;
    constructor(escrowService: EscrocontractsService);
    create(dto: CreateEscrowContractDto, req: any, file?: Express.Multer.File): Promise<{
        inviteToken: string;
        id: number;
        title: string;
        amount: number;
        transactionId?: string;
        senderCardId?: string;
        receiverCardId?: string;
        executorId?: number;
        deadline: number;
        technicalTermsFile?: string | null;
        generatedContractText?: string | null;
        status: EscrowStatus;
        executorPhoneNumber: string;
        rejectionReason?: string | null;
        createdAt: Date;
        creator: import("../user/entities/user.entity").User;
        creatorId: number;
    }>;
    findAll(req: any): Promise<import("./entities/escrocontract.entity").EscrowContract[]>;
    resolveInvite(token: string): Promise<{
        action: string;
        contractId: any;
        phoneNumber: any;
        token: string;
        contract: {
            title: string;
            amount: number;
        } | null;
    }>;
    getByToken(token: string, req: any): Promise<import("./entities/escrocontract.entity").EscrowContract>;
    updateStatus(id: number, status: EscrowStatus, req: any, cardId?: string, reason?: string): Promise<import("./entities/escrocontract.entity").EscrowContract>;
    update(id: number, dto: any, req: any, file?: Express.Multer.File): Promise<import("./entities/escrocontract.entity").EscrowContract>;
    findAllAdmin(): Promise<import("./entities/escrocontract.entity").EscrowContract[]>;
    findOne(id: number, req: any): Promise<import("./entities/escrocontract.entity").EscrowContract>;
    cancel(id: number, req: any): Promise<import("./entities/escrocontract.entity").EscrowContract>;
}
