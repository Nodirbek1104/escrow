"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var SmsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SmsService = void 0;
const common_1 = require("@nestjs/common");
const axios_1 = __importDefault(require("axios"));
let SmsService = SmsService_1 = class SmsService {
    logger = new common_1.Logger(SmsService_1.name);
    cachedToken = null;
    async send(phone, message) {
        if (process.env.NODE_ENV === 'development' || process.env.SMS_MODE === 'test') {
            console.log('\n🚀 [SMS TEST REJIMI]');
            console.log(`📍 Kimga: ${phone}`);
            console.log(`📝 Matn : ${message}`);
            console.log('----------------------------------------------\n');
            return;
        }
        try {
            await this.sendEskiz(phone, message);
        }
        catch (error) {
            this.logger.error(`SMS yuborishda xatolik: ${error.message}`);
        }
    }
    async getAuthToken(forceRefresh = false) {
        if (this.cachedToken && !forceRefresh) {
            return this.cachedToken;
        }
        try {
            const authRes = await axios_1.default.post('https://notify.eskiz.uz/api/auth/login', {
                email: process.env.ESKIZ_EMAIL,
                password: process.env.ESKIZ_SECRET,
            });
            const token = authRes.data.data.token;
            this.cachedToken = token;
            return token;
        }
        catch (error) {
            this.logger.error("Eskiz API'dan token olishda xatolik yuz berdi.");
            throw error;
        }
    }
    async sendEskiz(phone, message, retry = true) {
        try {
            const token = await this.getAuthToken();
            const cleanPhone = phone.replace(/[^\d]/g, '');
            const testmessage = "Bu Eskiz dan test";
            await axios_1.default.post('https://notify.eskiz.uz/api/message/sms/send', {
                mobile_phone: cleanPhone,
                message: testmessage,
                from: process.env.ESKIZ_FROM ?? '4546',
            }, {
                headers: { Authorization: `Bearer ${token}` },
            });
            this.logger.log(`SMS muvaffaqiyatli yuborildi: ${cleanPhone}`);
        }
        catch (error) {
            if (axios_1.default.isAxiosError(error)) {
                const axiosError = error;
                if (axiosError.response?.status === 401 && retry) {
                    this.logger.warn('Token eskirgan, yangilanmoqda...');
                    this.cachedToken = null;
                    return this.sendEskiz(phone, message, false);
                }
                this.logger.error(`Eskiz API xatosi: ${JSON.stringify(axiosError.response?.data)}`);
            }
            throw error;
        }
    }
};
exports.SmsService = SmsService;
exports.SmsService = SmsService = SmsService_1 = __decorate([
    (0, common_1.Injectable)()
], SmsService);
//# sourceMappingURL=sms.service.js.map