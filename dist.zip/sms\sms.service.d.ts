export declare class SmsService {
    private readonly logger;
    private cachedToken;
    send(phone: string, message: string): Promise<void>;
    private getAuthToken;
    private sendEskiz;
}
