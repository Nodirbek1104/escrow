import { Repository } from 'typeorm';
import { EscrowContract, EscrowStatus } from './entities/escrocontract.entity';
import { CreateEscrowContractDto } from './dto/create-escrocontract.dto';
import { User } from '../user/entities/user.entity';
import { SmsService } from '../user/send.sms.service';
import Redis from 'ioredis';
import { PaymentService } from '../payment/payment.service';
import { NotificationsService } from '../notifications/notifications.service';
export declare class EscrocontractsService {
    private readonly contractRepo;
    private readonly userRepo;
    private readonly smsService;
    private readonly paymentService;
    private readonly notificationsService;
    private readonly redis;
    private readonly logger;
    constructor(contractRepo: Repository<EscrowContract>, userRepo: Repository<User>, smsService: SmsService, paymentService: PaymentService, notificationsService: NotificationsService, redis: Redis);
    create(dto: CreateEscrowContractDto, user: any, filePath?: string): Promise<{
        inviteToken: string;
        id: number;
        title: string;
        amount: number;
        transactionId?: string;
        senderCardId?: string;
        receiverCardId?: string;
        executorId?: number;
        deadline: number;
        technicalTermsFile?: string | null;
        generatedContractText?: string | null;
        status: EscrowStatus;
        executorPhoneNumber: string;
        rejectionReason?: string | null;
        createdAt: Date;
        creator: User;
        creatorId: number;
    }>;
    resolveInvite(token: string): Promise<{
        action: string;
        contractId: any;
        phoneNumber: any;
        token: string;
        contract: {
            title: string;
            amount: number;
        } | null;
    }>;
    updateStatus(id: number, status: EscrowStatus, user: any, data?: {
        reason?: string;
        cardId?: string;
    }): Promise<EscrowContract>;
    findOne(id: number, user: any): Promise<EscrowContract>;
    cancel(id: number, user: any): Promise<EscrowContract>;
    private sendInviteSms;
    private validateStatusTransition;
    getContractByToken(token: string, user: any): Promise<EscrowContract>;
    findAllByUser(user: any): Promise<EscrowContract[]>;
    findAllAdmin(): Promise<EscrowContract[]>;
    update(id: number, dto: any, user: any, filePath?: string): Promise<EscrowContract>;
}
