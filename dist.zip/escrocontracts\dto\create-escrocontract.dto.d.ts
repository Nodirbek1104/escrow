export declare class CreateEscrowContractDto {
    title: string;
    amount: number;
    deadline: number;
    executorPhoneNumber: string;
}
