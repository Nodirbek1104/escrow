"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var UserService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const user_entity_1 = require("./entities/user.entity");
const jwt_1 = require("@nestjs/jwt");
const bcrypt = __importStar(require("bcrypt"));
const ioredis_1 = require("@nestjs-modules/ioredis");
const ioredis_2 = __importDefault(require("ioredis"));
const dotenv_1 = __importDefault(require("dotenv"));
const send_sms_service_1 = require("./send.sms.service");
dotenv_1.default.config();
let UserService = UserService_1 = class UserService {
    redis;
    userRepository;
    jwtService;
    smsService;
    logger = new common_1.Logger(UserService_1.name);
    constructor(redis, userRepository, jwtService, smsService) {
        this.redis = redis;
        this.userRepository = userRepository;
        this.jwtService = jwtService;
        this.smsService = smsService;
    }
    async onModuleInit() {
        await this.createInitialSuperAdmin();
    }
    async createInitialSuperAdmin() {
        const superAdminPhone = process.env.SUPER_ADMIN_PHONE;
        const superAdminPass = process.env.SUPER_ADMIN_PASSWORD;
        if (!superAdminPhone || !superAdminPass) {
            console.warn('⚠️ Super Admin maʼlumotlari .env faylda topilmadi!');
            return;
        }
        const adminExists = await this.userRepository.findOne({
            where: { role: user_entity_1.UserRole.SUPER_ADMIN }
        });
        if (!adminExists) {
            const hashedPassword = await bcrypt.hash(superAdminPass, 10);
            const superAdmin = this.userRepository.create({
                phoneNumber: superAdminPhone,
                fullName: 'Asosiy Super Admin',
                password: hashedPassword,
                role: user_entity_1.UserRole.SUPER_ADMIN,
                isVerified: true,
            });
            await this.userRepository.save(superAdmin);
            console.log('✅ Super Admin muvaffaqiyatli yaratildi!');
        }
    }
    async findByRole(role) {
        return this.userRepository.find({ where: { role } });
    }
    async sendOtp(dto) {
        const existingUser = await this.userRepository.findOneBy({ phoneNumber: dto.phoneNumber });
        if (existingUser) {
            throw new common_1.BadRequestException("Bu telefon raqami allaqachon ro'yxatdan o'tgan!");
        }
        const otp = Math.floor(1000 + Math.random() * 9000).toString();
        console.log('------------------------------------------');
        console.log(`[REGISTRATSIYA] Tel: ${dto.phoneNumber}`);
        console.log(`[KOD]: ${otp}`);
        console.log('------------------------------------------');
        await this.redis.set(`otp:${dto.phoneNumber}`, otp, 'EX', 300);
        try {
            await this.smsService.send(dto.phoneNumber, `Escro tasdiqlash kodi: ${otp}`);
        }
        catch (error) {
            this.logger.error(`SMS yuborishda xatolik: ${error}`);
        }
        return {
            message: "Tasdiqlash kodi yuborildi.",
            hint: "Test rejimidasiz, kodni terminaldan oling"
        };
    }
    async forgotPassword(dto) {
        const user = await this.userRepository.findOneBy({ phoneNumber: dto.phoneNumber });
        if (!user)
            throw new common_1.NotFoundException("Foydalanuvchi topilmadi");
        const otp = Math.floor(1000 + Math.random() * 9000).toString();
        await this.redis.set(`reset_otp:${dto.phoneNumber}`, otp, 'EX', 300);
        await this.smsService.send(dto.phoneNumber, `Escro parolni tiklash kodi: ${otp}`);
        console.log('------------------------------------------');
        console.log(`[PAROL TIKLASH] Tel: ${dto.phoneNumber}`);
        console.log(`[KOD]: ${otp}`);
        console.log('------------------------------------------');
        return { message: "Parolni tiklash kodi yuborildi." };
    }
    ;
    async verifyOtp(dto) {
        const savedCode = await this.redis.get(`otp:${dto.phoneNumber}`);
        if (dto.code !== '7777' && (!savedCode || savedCode !== dto.code)) {
            throw new common_1.BadRequestException("Kod noto'g'ri yoki muddati o'tgan");
        }
        ;
        await this.redis.set(`verified:${dto.phoneNumber}`, 'true', 'EX', 600);
        await this.redis.del(`otp:${dto.phoneNumber}`);
        return { message: "Kod tasdiqlandi, endi ma'lumotlaringizni kiriting" };
    }
    ;
    async completeRegister(dto) {
        const isVerified = await this.redis.get(`verified:${dto.phoneNumber}`);
        if (!isVerified) {
            throw new common_1.BadRequestException("Avval telefon raqamingizni tasdiqlang");
        }
        ;
        const hashedPassword = await bcrypt.hash(dto.password, 10);
        let user = await this.userRepository.findOneBy({ phoneNumber: dto.phoneNumber });
        if (!user) {
            user = this.userRepository.create({ phoneNumber: dto.phoneNumber });
        }
        ;
        user.fullName = dto.fullName;
        user.password = hashedPassword;
        user.isVerified = true;
        await this.userRepository.save(user);
        await this.redis.del(`verified:${dto.phoneNumber}`);
        return { message: "Muvaffaqiyatli ro'yxatdan o'tdingiz" };
    }
    async login(dto) {
        const user = await this.userRepository.createQueryBuilder("user")
            .addSelect("user.password")
            .where("user.phoneNumber = :phone", { phone: dto.phoneNumber })
            .getOne();
        if (!user || !user.isVerified) {
            throw new common_1.UnauthorizedException("Foydalanuvchi topilmadi yoki tasdiqlanmagan");
        }
        const isMatch = await bcrypt.compare(dto.password, user.password);
        if (!isMatch) {
            throw new common_1.UnauthorizedException("Telefon raqami yoki parol noto'g'ri");
        }
        const payload = {
            sub: user.id,
            phoneNumber: user.phoneNumber,
            fullName: user.fullName,
            role: user.role
        };
        return {
            access_token: this.jwtService.sign(payload),
            user: {
                id: user.id,
                fullName: user.fullName,
                phoneNumber: user.phoneNumber,
                role: user.role
            }
        };
    }
    async logout(token, expiresIn) {
        await this.redis.set(token, 'blacklisted', 'EX', expiresIn);
        return { message: "Tizimdan muvaqqiyatli chiqildi" };
    }
    ;
    async updateProfile(userId, dto) {
        const user = await this.userRepository.findOne({ where: { id: userId } });
        if (!user)
            throw new common_1.NotFoundException("Foydalanuvchi topilmadi");
        if (dto.password) {
            dto.password = await bcrypt.hash(dto.password, 10);
        }
        Object.assign(user, dto);
        return this.userRepository.save(user);
    }
    async getProfile(userId) {
        const user = await this.userRepository.findOne({ where: { id: userId } });
        if (!user) {
            throw new common_1.NotFoundException("Foydalanuvchi topilmadi");
        }
        const userResponse = { ...user };
        delete userResponse.password;
        return userResponse;
    }
    async resetPassword(dto) {
        const savedCode = await this.redis.get(`reset_otp:${dto.phoneNumber}`);
        if (dto.code !== '7777' && (!savedCode || savedCode !== dto.code)) {
            throw new common_1.BadRequestException("Kod noto'g'ri yoki muddati o'tgan");
        }
        ;
        const user = await this.userRepository.findOneBy({ phoneNumber: dto.phoneNumber });
        if (!user)
            throw new common_1.NotFoundException("Foydalanuvchi topilmadi");
        user.password = await bcrypt.hash(dto.newPassword, 10);
        await this.userRepository.save(user);
        await this.redis.del(`reset_otp:${dto.phoneNumber}`);
        return { message: "Parolingiz muvaffaqiyatli yangilandi. Endi login qilishingiz mumkin." };
    }
    ;
    async findAll() {
        return await this.userRepository.find({
            order: { id: 'DESC' }
        });
    }
    async createAdmin(dto) {
        const hashedPassword = await bcrypt.hash(dto.password, 10);
        const newAdmin = this.userRepository.create({
            ...dto,
            password: hashedPassword,
            role: dto.role || user_entity_1.UserRole.ADMIN,
            isVerified: true,
        });
        return await this.userRepository.save(newAdmin);
    }
    async update(id, dto) {
        const user = await this.userRepository.findOneBy({ id });
        if (!user)
            throw new common_1.NotFoundException("Foydalanuvchi topilmadi");
        if (dto.password) {
            dto.password = await bcrypt.hash(dto.password, 10);
        }
        Object.assign(user, dto);
        return await this.userRepository.save(user);
    }
    async remove(id, admin) {
        const user = await this.userRepository.findOneBy({ id });
        if (!user)
            throw new common_1.NotFoundException("Foydalanuvchi topilmadi");
        if (user.role === user_entity_1.UserRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException("Super Adminni tizimdan o'chirib bo'lmaydi!");
        }
        if (user.role === user_entity_1.UserRole.ADMIN && admin.role !== user_entity_1.UserRole.SUPER_ADMIN) {
            throw new common_1.ForbiddenException("Adminlarni faqat Super Admin o'chira oladi!");
        }
        return await this.userRepository.remove(user);
    }
};
exports.UserService = UserService;
exports.UserService = UserService = UserService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, ioredis_1.InjectRedis)()),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [ioredis_2.default,
        typeorm_2.Repository,
        jwt_1.JwtService,
        send_sms_service_1.SmsService])
], UserService);
//# sourceMappingURL=user.service.js.map