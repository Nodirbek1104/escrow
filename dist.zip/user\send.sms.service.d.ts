import Redis from 'ioredis';
export declare class SmsService {
    private readonly redis;
    private readonly logger;
    constructor(redis: Redis);
    private getEskizToken;
    send(phoneNumber: string, message: string): Promise<void>;
}
