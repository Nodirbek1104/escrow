"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EscrowContract = exports.EscrowStatus = void 0;
const typeorm_1 = require("typeorm");
const user_entity_1 = require("../../user/entities/user.entity");
var EscrowStatus;
(function (EscrowStatus) {
    EscrowStatus["DRAFT"] = "draft";
    EscrowStatus["PENDING"] = "pending";
    EscrowStatus["REVISION"] = "revision";
    EscrowStatus["REJECTED"] = "rejected";
    EscrowStatus["ACCEPTED"] = "accepted";
    EscrowStatus["PAYMENT_HELD"] = "payment_held";
    EscrowStatus["ACTIVE"] = "active";
    EscrowStatus["COMPLETED"] = "completed";
    EscrowStatus["CANCELLED"] = "cancelled";
    EscrowStatus["DISPUTED"] = "disputed";
})(EscrowStatus || (exports.EscrowStatus = EscrowStatus = {}));
let EscrowContract = class EscrowContract {
    id;
    title;
    amount;
    transactionId;
    senderCardId;
    receiverCardId;
    executorId;
    deadline;
    technicalTermsFile;
    generatedContractText;
    status;
    executorPhoneNumber;
    rejectionReason;
    createdAt;
    creator;
    creatorId;
};
exports.EscrowContract = EscrowContract;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], EscrowContract.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", String)
], EscrowContract.prototype, "title", void 0);
__decorate([
    (0, typeorm_1.Column)('decimal', {
        precision: 12,
        scale: 2,
        transformer: {
            to: (value) => value,
            from: (value) => parseFloat(value),
        },
    }),
    __metadata("design:type", Number)
], EscrowContract.prototype, "amount", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], EscrowContract.prototype, "transactionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], EscrowContract.prototype, "senderCardId", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], EscrowContract.prototype, "receiverCardId", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", Number)
], EscrowContract.prototype, "executorId", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", Number)
], EscrowContract.prototype, "deadline", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', nullable: true }),
    __metadata("design:type", Object)
], EscrowContract.prototype, "technicalTermsFile", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], EscrowContract.prototype, "generatedContractText", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: EscrowStatus, default: EscrowStatus.PENDING }),
    __metadata("design:type", String)
], EscrowContract.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", String)
], EscrowContract.prototype, "executorPhoneNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", Object)
], EscrowContract.prototype, "rejectionReason", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], EscrowContract.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => user_entity_1.User, (user) => user.id),
    (0, typeorm_1.JoinColumn)({ name: 'creatorId' }),
    __metadata("design:type", user_entity_1.User)
], EscrowContract.prototype, "creator", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", Number)
], EscrowContract.prototype, "creatorId", void 0);
exports.EscrowContract = EscrowContract = __decorate([
    (0, typeorm_1.Entity)('escrow_contracts')
], EscrowContract);
//# sourceMappingURL=escrocontract.entity.js.map