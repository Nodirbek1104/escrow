import { UserRole } from "../entities/user.entity";
export declare class UpdateUserDto {
    fullName?: string;
    phoneNumber?: string;
    password?: string;
    avatarUrl?: string;
    role?: UserRole;
}
