import { Repository } from 'typeorm';
import { User, UserRole } from './entities/user.entity';
import { SendOtpDto, CompleteRegisterDto, LoginDto, VerifyOtpDto, ResetPasswordDto, ForgotPasswordDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { JwtService } from '@nestjs/jwt';
import Redis from 'ioredis';
import { AdminCreateDto } from './dto/create-admin.dto';
import { SmsService } from './send.sms.service';
export declare class UserService {
    private readonly redis;
    private userRepository;
    private jwtService;
    private readonly smsService;
    private readonly logger;
    constructor(redis: Redis, userRepository: Repository<User>, jwtService: JwtService, smsService: SmsService);
    onModuleInit(): Promise<void>;
    private createInitialSuperAdmin;
    findByRole(role: UserRole): Promise<User[]>;
    sendOtp(dto: SendOtpDto): Promise<{
        message: string;
        hint: string;
    }>;
    forgotPassword(dto: ForgotPasswordDto): Promise<{
        message: string;
    }>;
    verifyOtp(dto: VerifyOtpDto): Promise<{
        message: string;
    }>;
    completeRegister(dto: CompleteRegisterDto): Promise<{
        message: string;
    }>;
    login(dto: LoginDto): Promise<{
        access_token: string;
        user: {
            id: number;
            fullName: string;
            phoneNumber: string;
            role: UserRole;
        };
    }>;
    logout(token: string, expiresIn: any): Promise<{
        message: string;
    }>;
    updateProfile(userId: number, dto: UpdateUserDto): Promise<User>;
    getProfile(userId: number): Promise<{
        id: number;
        phoneNumber: string;
        fullName: string;
        password: string;
        isVerified: boolean;
        role: UserRole;
        otpCode?: string | null;
        otpExpires?: Date | null;
        createdContracts: import("../escrocontracts/entities/escrocontract.entity").EscrowContract[];
        cards: import("../payment/entities/payment.entity").Card[];
        createdAt: Date;
    }>;
    resetPassword(dto: ResetPasswordDto): Promise<{
        message: string;
    }>;
    findAll(): Promise<User[]>;
    createAdmin(dto: AdminCreateDto): Promise<User>;
    update(id: number, dto: UpdateUserDto): Promise<User>;
    remove(id: number, admin: any): Promise<User>;
}
