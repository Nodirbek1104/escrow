"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
var EscrocontractsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EscrocontractsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const uuid_1 = require("uuid");
const escrocontract_entity_1 = require("./entities/escrocontract.entity");
const user_entity_1 = require("../user/entities/user.entity");
const send_sms_service_1 = require("../user/send.sms.service");
const ioredis_1 = require("@nestjs-modules/ioredis");
const ioredis_2 = __importDefault(require("ioredis"));
const payment_service_1 = require("../payment/payment.service");
const notifications_service_1 = require("../notifications/notifications.service");
const INVITE_TTL = 60 * 60 * 24;
const FRONTEND_URL = process.env.FRONTEND_URL ?? 'http://localhost:3000';
let EscrocontractsService = EscrocontractsService_1 = class EscrocontractsService {
    contractRepo;
    userRepo;
    smsService;
    paymentService;
    notificationsService;
    redis;
    logger = new common_1.Logger(EscrocontractsService_1.name);
    constructor(contractRepo, userRepo, smsService, paymentService, notificationsService, redis) {
        this.contractRepo = contractRepo;
        this.userRepo = userRepo;
        this.smsService = smsService;
        this.paymentService = paymentService;
        this.notificationsService = notificationsService;
        this.redis = redis;
    }
    async create(dto, user, filePath) {
        try {
            const contract = this.contractRepo.create({
                ...dto,
                technicalTermsFile: filePath,
                status: escrocontract_entity_1.EscrowStatus.PENDING,
                creatorId: user.userId,
            });
            const saved = await this.contractRepo.save(contract);
            const token = await this.sendInviteSms(saved.id, dto.executorPhoneNumber);
            await this.notificationsService.create(user.userId, "Shartnoma yaratildi", `#ESC-${saved.id} raqamli shartnoma muvaffaqiyatli yaratildi. Ijrochi tasdiqlashini kuting.`, "contract_created", saved.id.toString());
            return { ...saved, inviteToken: token };
        }
        catch (error) {
            this.logger.error(`Create Error: ${error}`);
            throw error;
        }
    }
    async resolveInvite(token) {
        try {
            const raw = await this.redis.get(`contract_invite:${token}`);
            if (!raw)
                throw new common_1.BadRequestException("Link muddati o'tgan yoki xato");
            const payload = JSON.parse(raw);
            const user = await this.userRepo.findOne({ where: { phoneNumber: payload.phone } });
            const contract = await this.contractRepo.findOne({ where: { id: payload.contractId } });
            return {
                action: user ? 'login' : 'register',
                contractId: payload.contractId,
                phoneNumber: payload.phone,
                token,
                contract: contract ? {
                    title: contract.title,
                    amount: contract.amount,
                } : null
            };
        }
        catch (error) {
            this.logger.error(`ResolveInvite Error: ${error}`);
            throw error;
        }
    }
    async updateStatus(id, status, user, data) {
        try {
            const contract = await this.findOne(id, user);
            this.validateStatusTransition(contract.status, status);
            if (status === escrocontract_entity_1.EscrowStatus.ACCEPTED && user.userId === contract.creatorId) {
                if (!data?.cardId) {
                    throw new common_1.BadRequestException('Shartnomani tasdiqlash uchun karta kiritish shart!');
                }
                const holdResult = await this.paymentService.holdFunds(user.userId, data.cardId, contract.amount, contract.id.toString());
                if (holdResult.result?.transactionId) {
                    contract.transactionId = holdResult.result.transactionId;
                    contract.senderCardId = data.cardId;
                    contract.status = escrocontract_entity_1.EscrowStatus.PAYMENT_HELD;
                }
                else {
                    throw new common_1.BadRequestException('Kartada mablag‘ yetarli emas yoki hold jarayonida xatolik!');
                }
            }
            else if (status === escrocontract_entity_1.EscrowStatus.ACCEPTED) {
                if (!data?.cardId) {
                    throw new common_1.BadRequestException('Shartnomani qabul qilish uchun pul tushadigan kartangizni tanlang!');
                }
                contract.receiverCardId = data.cardId;
                contract.status = escrocontract_entity_1.EscrowStatus.ACCEPTED;
            }
            if (status === escrocontract_entity_1.EscrowStatus.COMPLETED) {
                const isAdmin = user.role === 'admin' || user.role === 'super_admin';
                if (!isAdmin && contract.creatorId !== user.userId) {
                    throw new common_1.ForbiddenException('Faqat ijrochi yoki Admin yopishi mumkin');
                }
                const res = await this.paymentService.fulfillEscrow(contract.transactionId, contract.receiverCardId);
                if (!res.result)
                    throw new common_1.BadRequestException('To‘lovni amalga oshirishda xatolik');
                contract.status = escrocontract_entity_1.EscrowStatus.COMPLETED;
            }
            if (data?.reason)
                contract.rejectionReason = data.reason;
            if (status === escrocontract_entity_1.EscrowStatus.DISPUTED) {
                if (!data?.reason) {
                    throw new common_1.BadRequestException('Nizo ochish uchun sabab ko‘rsatish shart!');
                }
                contract.status = escrocontract_entity_1.EscrowStatus.DISPUTED;
            }
            const savedContract = await this.contractRepo.save(contract);
            const targetUserId = (user.userId === savedContract.creatorId) ? savedContract.executorId : savedContract.creatorId;
            if (targetUserId) {
                await this.notificationsService.create(targetUserId, "Shartnoma holati o'zgardi", `#ESC-${savedContract.id} shartnomasi "${status}" holatiga o'tkazildi.`, "contract_update", savedContract.id.toString());
            }
            return savedContract;
        }
        catch (error) {
            this.logger.error(`UpdateStatus Error: ${error}`);
            throw error;
        }
    }
    async findOne(id, user) {
        try {
            const contract = await this.contractRepo.findOne({
                where: { id },
                relations: ['creator']
            });
            if (!contract)
                throw new common_1.NotFoundException('Shartnoma topilmadi');
            const isAdmin = user.role === 'admin' || user.role === 'super_admin';
            if (!isAdmin && contract.creatorId !== user.userId && contract.executorPhoneNumber !== user.phoneNumber) {
                throw new common_1.ForbiddenException('Sizda ushbu shartnomani ko‘rish huquqi yo‘q');
            }
            return contract;
        }
        catch (error) {
            if (error instanceof common_1.NotFoundException)
                throw error;
            throw new common_1.BadRequestException('Maʼlumotni olishda xato');
        }
    }
    async cancel(id, user) {
        try {
            const contract = await this.findOne(id, user);
            const isAdmin = user.role === 'admin' || user.role === 'super_admin';
            if (!isAdmin && contract.creatorId !== user.userId) {
                throw new common_1.ForbiddenException('Bekor qilish huquqi yo‘q');
            }
            if (contract.status === escrocontract_entity_1.EscrowStatus.PAYMENT_HELD) {
                await this.paymentService.cancelTransaction(contract.transactionId);
            }
            contract.status = escrocontract_entity_1.EscrowStatus.CANCELLED;
            return await this.contractRepo.save(contract);
        }
        catch (error) {
            this.logger.error(`Cancel Error: ${error}`);
            throw error;
        }
    }
    async sendInviteSms(contractId, phone) {
        const token = (0, uuid_1.v4)();
        await this.redis.setex(`contract_invite:${token}`, INVITE_TTL, JSON.stringify({ contractId, phone }));
        const inviteLink = `${FRONTEND_URL}/invite/${token}`;
        try {
            await this.smsService.send(phone, `Bu Eskiz dan test`);
        }
        catch (error) {
            this.logger.error(`SMS yuborishda xato: ${error}`);
        }
        return token;
    }
    validateStatusTransition(current, next) {
        if (current === escrocontract_entity_1.EscrowStatus.COMPLETED || current === escrocontract_entity_1.EscrowStatus.CANCELLED) {
            throw new common_1.BadRequestException('Yopilgan shartnomani o‘zgartirib bo‘lmaydi');
        }
    }
    async getContractByToken(token, user) {
        const raw = await this.redis.get(`contract_invite:${token}`);
        if (!raw)
            throw new common_1.BadRequestException("Link muddati o'tgan");
        const payload = JSON.parse(raw);
        const payloadPhone = payload?.phone ? String(payload.phone).replace(/\D/g, '') : null;
        const userPhone = user?.phoneNumber ? String(user.phoneNumber).replace(/\D/g, '') : null;
        if (!userPhone) {
            this.logger.error(`Foydalanuvchi ob'ektida phoneNumber topilmadi: ${JSON.stringify(user)}`);
            throw new common_1.ForbiddenException("Profilingizda telefon raqami ko'rsatilmagan (JWT xatosi)");
        }
        if (!payloadPhone) {
            throw new common_1.BadRequestException("Link ma'lumotlari buzilgan yoki telefon raqami topilmadi");
        }
        if (payloadPhone !== userPhone) {
            throw new common_1.ForbiddenException('Bu link boshqa telefon raqamiga tegishli');
        }
        return this.findOne(payload.contractId, user);
    }
    async findAllByUser(user) {
        return this.contractRepo.find({
            where: [
                { creatorId: user.userId },
                { executorPhoneNumber: user.phoneNumber },
            ],
            relations: ['creator'],
            order: { createdAt: 'DESC' },
        });
    }
    async findAllAdmin() {
        return this.contractRepo.find({
            relations: ['creator'],
            order: { createdAt: 'DESC' },
        });
    }
    async update(id, dto, user, filePath) {
        try {
            const contract = await this.findOne(id, user);
            if (contract.creatorId !== user.userId) {
                throw new common_1.ForbiddenException('Sizda ushbu shartnomani tahrirlash huquqi yo‘q');
            }
            if (contract.status !== escrocontract_entity_1.EscrowStatus.PENDING) {
                throw new common_1.BadRequestException('Faqat kutilayotgan (PENDING) shartnomalarni tahrirlash mumkin');
            }
            Object.assign(contract, dto);
            if (filePath) {
                contract.technicalTermsFile = filePath;
            }
            return await this.contractRepo.save(contract);
        }
        catch (error) {
            this.logger.error(`Update Error: ${error}`);
            throw error;
        }
    }
};
exports.EscrocontractsService = EscrocontractsService;
exports.EscrocontractsService = EscrocontractsService = EscrocontractsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(escrocontract_entity_1.EscrowContract)),
    __param(1, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __param(5, (0, ioredis_1.InjectRedis)()),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        send_sms_service_1.SmsService,
        payment_service_1.PaymentService,
        notifications_service_1.NotificationsService,
        ioredis_2.default])
], EscrocontractsService);
//# sourceMappingURL=escrocontracts.service.js.map