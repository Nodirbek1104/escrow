"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const jwt_1 = require("@nestjs/jwt");
const user_service_1 = require("./user.service");
const user_controller_1 = require("./user.controller");
const user_entity_1 = require("./entities/user.entity");
const super_admin_seed_1 = require("./super-admin.seed");
const admin_controller_1 = require("./admin.controller");
const auth_module_1 = require("../auth/auth.module");
const dotenv_1 = __importDefault(require("dotenv"));
const user_device_entity_1 = require("./entities/user-device.entity");
const jwt_strategy_1 = require("./jwt.strategy");
const sms_module_1 = require("./sms.module");
const audit_log_module_1 = require("../audit-log/audit-log.module");
dotenv_1.default.config();
let UserModule = class UserModule {
};
exports.UserModule = UserModule;
exports.UserModule = UserModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([user_entity_1.User, user_device_entity_1.UserDevice]),
            jwt_1.JwtModule.register({
                secret: process.env.JWT_SECRET,
                signOptions: { expiresIn: '1d' },
            }),
            auth_module_1.AuthModule,
            sms_module_1.SmsModule,
            audit_log_module_1.AuditLogModule
        ],
        controllers: [user_controller_1.UserController, admin_controller_1.AdminController],
        providers: [user_service_1.UserService, super_admin_seed_1.SuperAdminSeed, jwt_strategy_1.JwtStrategy],
        exports: [user_service_1.UserService, typeorm_1.TypeOrmModule],
    })
], UserModule);
//# sourceMappingURL=user.module.js.map