export declare class EscrocontractsModule {
}
