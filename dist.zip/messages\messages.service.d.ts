import { Repository } from 'typeorm';
import { Message } from './entities/message.entity';
export declare class MessagesService {
    private readonly messageRepository;
    constructor(messageRepository: Repository<Message>);
    create(contractId: number, content: string, senderId: number, fileUrl?: string): Promise<Message>;
    findByContract(contractId: number): Promise<Message[]>;
}
