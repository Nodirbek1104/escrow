"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EscrocontractsController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const escrocontracts_service_1 = require("./escrocontracts.service");
const create_escrocontract_dto_1 = require("./dto/create-escrocontract.dto");
const escrocontract_entity_1 = require("./entities/escrocontract.entity");
const jwt_auth_guard_1 = require("../auth/guards/jwt-auth.guard");
const multer_1 = require("multer");
const path_1 = require("path");
const audit_log_interceptor_1 = require("../audit-log/audit-log.interceptor");
const admin_guard_1 = require("../auth/guards/admin.guard");
let EscrocontractsController = class EscrocontractsController {
    escrowService;
    constructor(escrowService) {
        this.escrowService = escrowService;
    }
    async create(dto, req, file) {
        return this.escrowService.create(dto, req.user, file?.path);
    }
    async findAll(req) {
        return this.escrowService.findAllByUser(req.user);
    }
    async resolveInvite(token) {
        return this.escrowService.resolveInvite(token);
    }
    async getByToken(token, req) {
        return this.escrowService.getContractByToken(token, req.user);
    }
    async updateStatus(id, status, req, cardId, reason) {
        return this.escrowService.updateStatus(id, status, req.user, {
            cardId,
            reason,
        });
    }
    async update(id, dto, req, file) {
        return this.escrowService.update(id, dto, req.user, file?.path);
    }
    async findAllAdmin() {
        return this.escrowService.findAllAdmin();
    }
    async findOne(id, req) {
        return this.escrowService.findOne(id, req.user);
    }
    async cancel(id, req) {
        return this.escrowService.cancel(id, req.user);
    }
};
exports.EscrocontractsController = EscrocontractsController;
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Post)(),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: (0, multer_1.diskStorage)({
            destination: './uploads/contracts',
            filename: (req, file, cb) => {
                const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
                cb(null, `${uniqueSuffix}${(0, path_1.extname)(file.originalname)}`);
            },
        }),
    })),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Req)()),
    __param(2, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_escrocontract_dto_1.CreateEscrowContractDto, Object, Object]),
    __metadata("design:returntype", Promise)
], EscrocontractsController.prototype, "create", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)('my-contracts'),
    __param(0, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], EscrocontractsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('invite/resolve/:token'),
    __param(0, (0, common_1.Param)('token')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EscrocontractsController.prototype, "resolveInvite", null);
__decorate([
    (0, common_1.Get)('invite/details/:token'),
    __param(0, (0, common_1.Param)('token')),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], EscrocontractsController.prototype, "getByToken", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Patch)(':id/status'),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)('status')),
    __param(2, (0, common_1.Req)()),
    __param(3, (0, common_1.Body)('cardId')),
    __param(4, (0, common_1.Body)('reason')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String, Object, String, String]),
    __metadata("design:returntype", Promise)
], EscrocontractsController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Patch)(':id/update'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __param(2, (0, common_1.Req)()),
    __param(3, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object, Object, Object]),
    __metadata("design:returntype", Promise)
], EscrocontractsController.prototype, "update", null);
__decorate([
    (0, common_1.Get)('admin/all'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, admin_guard_1.AdminGuard),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], EscrocontractsController.prototype, "findAllAdmin", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", Promise)
], EscrocontractsController.prototype, "findOne", null);
__decorate([
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    (0, common_1.Delete)(':id/cancel'),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Req)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", Promise)
], EscrocontractsController.prototype, "cancel", null);
exports.EscrocontractsController = EscrocontractsController = __decorate([
    (0, common_1.Controller)('escrow-contracts'),
    (0, common_1.UseInterceptors)(audit_log_interceptor_1.AuditInterceptor),
    __metadata("design:paramtypes", [escrocontracts_service_1.EscrocontractsService])
], EscrocontractsController);
//# sourceMappingURL=escrocontracts.controller.js.map