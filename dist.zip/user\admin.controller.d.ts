import { UserService } from './user.service';
import { UpdateUserDto } from './dto/update-user.dto';
import { AdminCreateDto } from './dto/create-admin.dto';
export declare class AdminController {
    private readonly userService;
    constructor(userService: UserService);
    findAll(): Promise<import("./entities/user.entity").User[]>;
    checkRoot(): Promise<import("./entities/user.entity").User[]>;
    createAdmin(dto: AdminCreateDto): Promise<import("./entities/user.entity").User>;
    update(id: number, dto: UpdateUserDto, req: any): Promise<import("./entities/user.entity").User>;
    remove(id: number, req: any): Promise<import("./entities/user.entity").User>;
}
