import { CreateEscrowContractDto } from './create-escrocontract.dto';
declare const UpdateEscrocontractDto_base: import("@nestjs/mapped-types").MappedType<Partial<CreateEscrowContractDto>>;
export declare class UpdateEscrocontractDto extends UpdateEscrocontractDto_base {
}
export {};
