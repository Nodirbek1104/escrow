export declare function handlePaymentError(error: unknown): {
    result: null;
    error: any;
};
