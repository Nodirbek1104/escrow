"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CheckCardFieldDto = exports.ConfirmCardDto = exports.CreateCardDto = void 0;
class CreateCardDto {
    userId;
    cardNumber;
    expireDate;
    phoneNumber;
}
exports.CreateCardDto = CreateCardDto;
class ConfirmCardDto {
    cardId;
    otp;
    cardName;
    pinfl;
}
exports.ConfirmCardDto = ConfirmCardDto;
class CheckCardFieldDto {
    cardId;
    pinfl;
    phone;
}
exports.CheckCardFieldDto = CheckCardFieldDto;
//# sourceMappingURL=create-payment.dto.js.map