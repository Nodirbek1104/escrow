export declare class AuditLogModule {
}
