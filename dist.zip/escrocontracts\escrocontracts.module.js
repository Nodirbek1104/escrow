"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EscrocontractsModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const escrocontracts_service_1 = require("./escrocontracts.service");
const escrocontracts_controller_1 = require("./escrocontracts.controller");
const escrocontract_entity_1 = require("./entities/escrocontract.entity");
const user_entity_1 = require("../user/entities/user.entity");
const sms_module_1 = require("../user/sms.module");
const audit_log_module_1 = require("../audit-log/audit-log.module");
const payment_module_1 = require("../payment/payment.module");
const notifications_module_1 = require("../notifications/notifications.module");
let EscrocontractsModule = class EscrocontractsModule {
};
exports.EscrocontractsModule = EscrocontractsModule;
exports.EscrocontractsModule = EscrocontractsModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([escrocontract_entity_1.EscrowContract, user_entity_1.User]), audit_log_module_1.AuditLogModule, sms_module_1.SmsModule, payment_module_1.PaymentModule, sms_module_1.SmsModule, notifications_module_1.NotificationsModule],
        controllers: [escrocontracts_controller_1.EscrocontractsController],
        providers: [escrocontracts_service_1.EscrocontractsService],
        exports: [escrocontracts_service_1.EscrocontractsService]
    })
], EscrocontractsModule);
//# sourceMappingURL=escrocontracts.module.js.map