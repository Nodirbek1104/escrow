"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateEscrocontractDto = void 0;
const mapped_types_1 = require("@nestjs/mapped-types");
const create_escrocontract_dto_1 = require("./create-escrocontract.dto");
class UpdateEscrocontractDto extends (0, mapped_types_1.PartialType)(create_escrocontract_dto_1.CreateEscrowContractDto) {
}
exports.UpdateEscrocontractDto = UpdateEscrocontractDto;
//# sourceMappingURL=update-escrocontract.dto.js.map