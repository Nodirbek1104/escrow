export declare class SmsModule {
}
