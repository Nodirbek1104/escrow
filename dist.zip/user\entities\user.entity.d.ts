import { EscrowContract } from "../../escrocontracts/entities/escrocontract.entity";
import { Card } from "../../payment/entities/payment.entity";
export declare enum UserRole {
    USER = "user",
    ADMIN = "admin",
    SUPER_ADMIN = "super_admin"
}
export declare class User {
    id: number;
    phoneNumber: string;
    fullName: string;
    password: string;
    isVerified: boolean;
    role: UserRole;
    otpCode?: string | null;
    otpExpires?: Date | null;
    createdContracts: EscrowContract[];
    cards: Card[];
    createdAt: Date;
}
