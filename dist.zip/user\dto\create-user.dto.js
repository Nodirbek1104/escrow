"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateUserDto = exports.ResetPasswordDto = exports.ForgotPasswordDto = exports.LoginDto = exports.CompleteRegisterDto = exports.VerifyOtpDto = exports.SendOtpDto = void 0;
const class_validator_1 = require("class-validator");
const user_entity_1 = require("../entities/user.entity");
class SendOtpDto {
    phoneNumber;
}
exports.SendOtpDto = SendOtpDto;
__decorate([
    (0, class_validator_1.IsNotEmpty)({ message: "Telefon raqami bo'sh bo'lmasligi kerak" }),
    (0, class_validator_1.IsPhoneNumber)('UZ', { message: "Telefon raqami noto'g'ri formatda (+998xxxxxxx)" }),
    __metadata("design:type", String)
], SendOtpDto.prototype, "phoneNumber", void 0);
class VerifyOtpDto {
    phoneNumber;
    code;
}
exports.VerifyOtpDto = VerifyOtpDto;
__decorate([
    (0, class_validator_1.IsPhoneNumber)('UZ'),
    __metadata("design:type", String)
], VerifyOtpDto.prototype, "phoneNumber", void 0);
__decorate([
    (0, class_validator_1.Length)(4, 6),
    __metadata("design:type", String)
], VerifyOtpDto.prototype, "code", void 0);
class CompleteRegisterDto {
    phoneNumber;
    fullName;
    password;
}
exports.CompleteRegisterDto = CompleteRegisterDto;
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsPhoneNumber)('UZ'),
    __metadata("design:type", String)
], CompleteRegisterDto.prototype, "phoneNumber", void 0);
__decorate([
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CompleteRegisterDto.prototype, "fullName", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.MinLength)(6, { message: "Parol kamida 6 ta belgidan iborat bo'lishi kerak" }),
    __metadata("design:type", String)
], CompleteRegisterDto.prototype, "password", void 0);
class LoginDto {
    phoneNumber;
    password;
}
exports.LoginDto = LoginDto;
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], LoginDto.prototype, "phoneNumber", void 0);
__decorate([
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], LoginDto.prototype, "password", void 0);
class ForgotPasswordDto {
    phoneNumber;
}
exports.ForgotPasswordDto = ForgotPasswordDto;
__decorate([
    (0, class_validator_1.IsPhoneNumber)('UZ'),
    __metadata("design:type", String)
], ForgotPasswordDto.prototype, "phoneNumber", void 0);
class ResetPasswordDto {
    phoneNumber;
    code;
    newPassword;
}
exports.ResetPasswordDto = ResetPasswordDto;
__decorate([
    (0, class_validator_1.IsPhoneNumber)('UZ'),
    __metadata("design:type", String)
], ResetPasswordDto.prototype, "phoneNumber", void 0);
__decorate([
    (0, class_validator_1.Length)(4, 6),
    __metadata("design:type", String)
], ResetPasswordDto.prototype, "code", void 0);
__decorate([
    (0, class_validator_1.MinLength)(6, { message: "Yangi parol kamida 6 belgidan iborat bo'lishi kerak" }),
    __metadata("design:type", String)
], ResetPasswordDto.prototype, "newPassword", void 0);
class UpdateUserDto {
    fullName;
    password;
    role;
    phoneNumber;
}
exports.UpdateUserDto = UpdateUserDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateUserDto.prototype, "fullName", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.MinLength)(6),
    __metadata("design:type", String)
], UpdateUserDto.prototype, "password", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(user_entity_1.UserRole, { message: "Noto'g'ri rol kiritildi" }),
    __metadata("design:type", String)
], UpdateUserDto.prototype, "role", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateUserDto.prototype, "phoneNumber", void 0);
//# sourceMappingURL=create-user.dto.js.map