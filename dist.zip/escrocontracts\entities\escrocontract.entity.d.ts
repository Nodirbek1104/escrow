import { User } from '../../user/entities/user.entity';
export declare enum EscrowStatus {
    DRAFT = "draft",
    PENDING = "pending",
    REVISION = "revision",
    REJECTED = "rejected",
    ACCEPTED = "accepted",
    PAYMENT_HELD = "payment_held",
    ACTIVE = "active",
    COMPLETED = "completed",
    CANCELLED = "cancelled",
    DISPUTED = "disputed"
}
export declare class EscrowContract {
    id: number;
    title: string;
    amount: number;
    transactionId?: string;
    senderCardId?: string;
    receiverCardId?: string;
    executorId?: number;
    deadline: number;
    technicalTermsFile?: string | null;
    generatedContractText?: string | null;
    status: EscrowStatus;
    executorPhoneNumber: string;
    rejectionReason?: string | null;
    createdAt: Date;
    creator: User;
    creatorId: number;
}
