import { CanActivate, ExecutionContext } from '@nestjs/common';
export declare class TelegramGuard implements CanActivate {
    private readonly logger;
    canActivate(context: ExecutionContext): boolean;
    private validate;
}
