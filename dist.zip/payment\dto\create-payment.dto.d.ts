export declare class CreateCardDto {
    userId: string;
    cardNumber: string;
    expireDate: string;
    phoneNumber: string;
}
export declare class ConfirmCardDto {
    cardId: string;
    otp: string;
    cardName: string;
    pinfl: string;
}
export declare class CheckCardFieldDto {
    cardId: string;
    pinfl?: string;
    phone?: string;
}
