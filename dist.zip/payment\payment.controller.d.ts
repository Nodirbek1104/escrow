import { PaymentService } from './payment.service';
export declare class PaymentController {
    private readonly paymentService;
    constructor(paymentService: PaymentService);
    createCard(req: any, body: any): Promise<any>;
    confirmCard(req: any, body: {
        cardId: string;
        otp: string;
        cardName: string;
        pinfl: string;
    }): Promise<any>;
    deleteCard(req: any, cardId: string): Promise<any>;
    getMyCards(req: any): Promise<{
        result: {
            cards: import("./entities/payment.entity").Card[];
        };
        error: null;
    } | {
        result: null;
        error: {
            code: string;
            message: string;
        };
    }>;
    getCardStatus(req: any, cardId: string): Promise<any>;
    checkPinfl(body: {
        cardId: string;
        pinfl: string;
    }): Promise<any>;
    checkPhone(body: {
        cardId: string;
        phone: string;
    }): Promise<any>;
    cancelTransaction(transactionId: string): Promise<any>;
    hold(req: any, body: {
        cardId: string;
        amount: number;
        contractId: string;
    }): Promise<any>;
    fulfill(body: {
        transactionId: string;
        receiverCardId: string;
    }): Promise<any>;
}
