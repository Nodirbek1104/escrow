import { Repository } from 'typeorm';
import { Card } from './entities/payment.entity';
import { ConfigService } from '@nestjs/config';
export declare class PaymentService {
    private cardRepository;
    private configService;
    private readonly client;
    private readonly logger;
    constructor(cardRepository: Repository<Card>, configService: ConfigService);
    createCard(userId: number | string, cardNumber: string, expireDate: string, phoneNumber: string): Promise<any>;
    confirmCard(userId: number, cardId: string, otp: string, cardName: string, pinfl: string): Promise<any>;
    deleteCard(userId: number, cardId: string): Promise<any>;
    getMyCards(userId: number): Promise<{
        result: {
            cards: Card[];
        };
        error: null;
    } | {
        result: null;
        error: {
            code: string;
            message: string;
        };
    }>;
    getCardDetails(userId: number, cardId: string): Promise<any>;
    checkCardData(cardId: string, type: 'pinfl' | 'phone', value: string): Promise<any>;
    cancelTransaction(transactionId: string): Promise<any>;
    holdFunds(userId: number, cardId: string, amount: number, contractId: string): Promise<any>;
    fulfillEscrow(transactionId: string, receiverCardId: string): Promise<any>;
}
