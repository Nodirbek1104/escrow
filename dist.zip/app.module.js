"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const serve_static_1 = require("@nestjs/serve-static");
const path_1 = require("path");
const config_1 = require("@nestjs/config");
const app_controller_1 = require("./app.controller");
const app_service_1 = require("./app.service");
const typeorm_1 = require("@nestjs/typeorm");
const user_module_1 = require("./user/user.module");
const dotenv_1 = __importDefault(require("dotenv"));
const ioredis_1 = require("@nestjs-modules/ioredis");
const escrocontracts_module_1 = require("./escrocontracts/escrocontracts.module");
const audit_log_module_1 = require("./audit-log/audit-log.module");
const core_1 = require("@nestjs/core");
const audit_log_interceptor_1 = require("./audit-log/audit-log.interceptor");
const payment_module_1 = require("./payment/payment.module");
const throttler_1 = require("@nestjs/throttler");
const core_2 = require("@nestjs/core");
const messages_module_1 = require("./messages/messages.module");
const notifications_module_1 = require("./notifications/notifications.module");
dotenv_1.default.config();
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                isGlobal: true,
            }),
            serve_static_1.ServeStaticModule.forRoot({
                rootPath: process.env.NODE_ENV === 'production'
                    ? '/home/ubuntu/escro-frontend/dist/client'
                    : (0, path_1.join)(__dirname, '..', 'uploads'),
                exclude: ['/api*'],
            }),
            throttler_1.ThrottlerModule.forRoot([{
                    ttl: 60000,
                    limit: 15,
                }]),
            ioredis_1.RedisModule.forRoot({
                type: 'single',
                url: 'redis://localhost:6379'
            }),
            typeorm_1.TypeOrmModule.forRoot({
                type: 'postgres',
                host: process.env.DB_HOST,
                port: Number(process.env.DB_PORT),
                username: process.env.DB_USERNAME,
                password: process.env.DB_PASSWORD,
                database: process.env.DB_DATABASE,
                autoLoadEntities: true,
                synchronize: true,
            }),
            user_module_1.UserModule,
            escrocontracts_module_1.EscrocontractsModule,
            audit_log_module_1.AuditLogModule,
            payment_module_1.PaymentModule,
            messages_module_1.MessagesModule,
            notifications_module_1.NotificationsModule,
        ],
        controllers: [app_controller_1.AppController],
        providers: [
            app_service_1.AppService,
            {
                provide: core_1.APP_INTERCEPTOR,
                useClass: audit_log_interceptor_1.AuditInterceptor,
            },
            {
                provide: core_2.APP_GUARD,
                useClass: throttler_1.ThrottlerGuard,
            },
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map