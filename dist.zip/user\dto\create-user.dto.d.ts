import { UserRole } from '../entities/user.entity';
export declare class SendOtpDto {
    phoneNumber: string;
}
export declare class VerifyOtpDto {
    phoneNumber: string;
    code: string;
}
export declare class CompleteRegisterDto {
    phoneNumber: string;
    fullName: string;
    password: string;
}
export declare class LoginDto {
    phoneNumber: string;
    password: string;
}
export declare class ForgotPasswordDto {
    phoneNumber: string;
}
export declare class ResetPasswordDto {
    phoneNumber: string;
    code: string;
    newPassword: string;
}
export declare class UpdateUserDto {
    fullName?: string;
    password?: string;
    role?: UserRole;
    phoneNumber?: string;
}
